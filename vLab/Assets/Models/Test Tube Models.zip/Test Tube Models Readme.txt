Hello and thank you for taking an interest in my models.

I bring to you a low-poly test tube as the second part of my labware series.  As always this model is brought to you in four formats:  .Cob, .3Ds, .DXF and .OBJ  to make it easier for you to use it with the modeling program of your choice.

As with the Conical Flask the .COB model is supplied shaded with the TS4.3 glass shader while all others are shaded in phong.   Also these models are completely royalty free to be used as you see fit-any way you see fit-private, public or commercial and can be redistributed with or without credit any way you choose.  

Please enjoy the model.


Cheers.

Chris Melvin