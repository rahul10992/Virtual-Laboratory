Greetings.  Thank you for taking an interest in my models.  

This conical flask is the first in a series of labware models I'm releasing to the public.  

The models are provided in four common model formats:  Caligari Object (.COB), 3D Studio Max (.3DS), Autodesk AUtocad Drawing Exchange File (.DXF) and Wavefront (.OBJ).

The Caligari Truespace 4.3 file is supplied shaded with the Caligari Glass Shader.  All others are plain shaded.  This is becauase there is a wealth of different shading/rendering/lighting engines out there each with its own idiosynchracies and I am not sure how they all function.  

These models are being released to the public ROYALTY FREE to with as anyone sees fit, even to redistribute or sell.  The reason for this?  Two fold:  

1.  I do not feel that people should have to pay out the nose for materials of artistic and educational purpose.  These models could be used by a panoply of different end users including:

Educators
Modelers/animators
Hobbyists
etc.

2.  The models are very nodescript and generally lacking in any original intellectual property and need not be protected as such.  

Please enjoy using these models in any way you see fit.  Render them for your own purposes, use them as part of an educational curriculum, analyze their design, Use them in a professional publication or redistribute them however you wish.  

Consider this my small gift to the artistic/educational community.

Thank you again and have fun.

Yours Truly,

C Melvin

* If you enjoyed this model please check out my portfolio at ShareCG.com at archoepterix2680.  It's small but it'll keep growing.